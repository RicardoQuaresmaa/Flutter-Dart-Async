# Flutter: Getting And Parsing JSON

Learning to access web data in flutter.
Uses the fake REST API at `https://jsonplaceholder.typicode.com/`